<?php 

//just for error loggin
error_reporting(1);
ini_set('display_errors', true);

//json data
$json = '{
"geonames": [{
    "adminCode1": "16",
    "lng": "74.19774",
    "distance": "2.95838",
    "geonameId": 1254611,
    "toponymName": "Thengode",
    "countryId": "1269750",
    "fcl": "P",
    "population": 0,
    "countryCode": "IN",
    "name": "Thengode",
    "fclName": "city, village,...",
    "countryName": "India",
    "fcodeName": "populated place",
    "adminName1": "Maharashtra",
    "lat": "20.51997",
    "fcode": "PPL"
}]}';

//decoded json object
$jsonDataObject = json_decode($json);

//parsed variables
$name = $jsonDataObject->geonames[0]->name;
$adminName1 = $jsonDataObject->geonames[0]->adminName1;
$countryCode = $jsonDataObject->geonames[0]->countryCode;
echo $name
?>
