<?php
$cutOffTime = "11";
$holidays = ["Saturday", "Sunday", "Monday", "Tuesday", "Wednesday"];
?>
