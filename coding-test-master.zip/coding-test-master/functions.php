<?php

//$date - Y-m-d format
function getShippingDate($orderDate, $oderTime) {
	return "CalculatedShippingDate";
}

?>